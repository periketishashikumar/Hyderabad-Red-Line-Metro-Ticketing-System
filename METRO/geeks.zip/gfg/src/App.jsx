import React from 'react'
import Bodyparent from './BodyParent'
import Footer from './Footer'
import Nav from './Nav'

const App = () => {
  return (<>
    <Nav/>
    <div style={{ height: '150px' }}>
    </div>
   <main className='root'>
   <Bodyparent/>
   </main>
   <div style={{ height: '50px' }}>
</div>
   <Footer/>
   </>
  )
}

export default App
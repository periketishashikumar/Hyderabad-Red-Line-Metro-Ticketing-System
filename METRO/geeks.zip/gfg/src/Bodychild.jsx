import React from 'react'

const Bodychild = ({images}) => {
  return (
        <article className='Crd-Container'>
            <span className='star'>⭐4.7</span>
            <section className='crd'>
                <aside className='crd-image'><img src={images.url} alt="Course Img" /></aside>
                <aside className='crd-desc'>{images.desc}</aside>
                <aside className='crd-mode'><i class="fa-solid fa-signal fa-xs"></i> {images.mode}</aside>
                <aside className='crd-intrests'><span>{images.intrests}</span><span id='2ndspan'>Explore Now</span></aside>
                <aside className='crd-btn'><button>Refund of 90% avialable on this course</button></aside>
            </section>
        </article>
  )
}

export default Bodychild
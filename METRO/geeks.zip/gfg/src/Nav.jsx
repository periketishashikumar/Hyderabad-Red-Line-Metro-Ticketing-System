import React from 'react'

const Nav = () => {
  return (
    <header id="main_nav">
      <nav id="sub_nav">
        <ol id="left_nav">
          <li>
            <a href="#">
              Courses &nbsp;
              <span>
                <i className="fa-solid fa-angle-down"></i>
              </span>
            </a>
            <div id="one">
              <ol>
                <li>DSA To Development</li>
                <li>GATE Course</li>
                <li>Get IBM Certification</li>
                <li>Data Science Program</li>
                <li>All Course</li>
              </ol>
            </div>
          </li>
          <li>
            <a href="#">
              Tutorials &nbsp;
              <span>
                <i className="fa-solid fa-angle-down"></i>
              </span>
            </a>
            <div id="two">
              <ol>
                <li>Data Structures And Algorithms</li>
                <li>ML & Data Science</li>
                <li>Interview Corner</li>
                <li>Languages</li>
                <li>Web Development</li>
              </ol>
            </div>
          </li>
          <li>
            <a href="#">
              Jobs &nbsp;
              <span>
                <i className="fa-solid fa-angle-down"></i>
              </span>
            </a>
            <div id="three">
              <ol>
                <li>Apply For Jobs</li>
                <li>Corporate Hiring Solution</li>
                <li>Employee Branding</li>
                <li>ALL Job Updates</li>
              </ol>
            </div>
          </li>
          <li>
            <a href="#">
              Practice &nbsp;
              <span>
                <i className="fa-solid fa-angle-down"></i>
              </span>
            </a>
            <div id="four">
              <ol>
                <li>160 days DSA</li>
                <li>Problem of the Day</li>
                <li>Practice Coding Problems</li>
                <li>GFG SDE Sheet</li>
              </ol>
            </div>
          </li>
          <li>
            <a href="#">
              Content &nbsp;
              <span>
                <i className="fa-solid fa-angle-down"></i>
              </span>
            </a>
            <div id="five">
              <ol>
                <li>GFG Weekly</li>
                <li>Job-A-Thon Hiring Challenge</li>
                <li>All Contents and Events</li>
              </ol>
            </div>
          </li>
        </ol>
        <span id="main_logo">
          <img src="https://media.geeksforgeeks.org/gfg-gg-logo.svg" alt="logo" />
        </span>
        <ol id="right_nav">
          <li>
            <a href="#">
              <span>
                <i className="fa-solid fa-magnifying-glass"></i>
              </span>
            </a>
          </li>
          <li>
            <a href="#" id="theme">
              <span>
                <i className="fa-solid fa-lightbulb"></i>
                <i className="fa-solid fa-moon"></i>
              </span>
            </a>
          </li>
          <li>
            <a href="#">
              <span>
                <i className="fa-solid fa-bell"></i>
              </span>
            </a>
          </li>
          <li>
            <a href="#">
              <span>
                <i className="fa-solid fa-user"></i>
              </span>
            </a>
          </li>
          <li>
            <a href="#">
              <button>Sign in</button>
            </a>
          </li>
        </ol>
      </nav>
    </header>
  )
}
setTimeout(() => {
    
let theme = document.querySelector('#theme')
theme.addEventListener('click',(e)=>{

    let sun = document.querySelector('.fa-lightbulb')

    let moon = document.querySelector('.fa-moon')

    sun.classList.toggle('display_sun')

    moon.classList.toggle('display_moon')

    let body = document.querySelector('body');

    body.classList.toggle('dark-theme');

});
    
}, 1);
export default Nav
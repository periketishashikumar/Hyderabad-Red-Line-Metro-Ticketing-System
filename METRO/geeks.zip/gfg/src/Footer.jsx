
function Footer(){
    return (<>
    <footer>
            <section class="main-footer">
                <article class="main-footer1">
                    <aside class="Support">
                        <ul>
                            <li class="first">SUPPORT</li>
                            <li>Online Help</li>
                            <li>Customer Service</li>
                            <li>Shipping FAQ</li>
                            <li>Warranty</li>
                            <li>Xiaomi Exchange</li>
                            <li>Bulk Orders</li>
                            <li>User Guide</li>
                            <li>Laptop Drivers</li>
                            <li>Mi Screen Protect</li>
                            <li>Mi Extended Warranty</li>
                            <li>MI Complete Protect</li>
                            <li>Certification </li>
                            <li>Service Center</li>
                            <li>Xiaomi Spotify India</li>
                        </ul>
                    </aside>
                <aside class="shop">
                    <ul>
                        <li class="first">SHOP AND LEARN</li>
                        <li>Xiaomi Phones</li>
                        <li>Redmi Phones</li>
                        <li>Tv's</li>
                        <li>Laptop's and Tablet's</li>
                        <li>Audio</li>
                        <li>Lifestyle</li>
                        <li>Smart Home</li>
                    </ul>
                </aside>
                <aside class="store">
                    <ul>
                        <li class="first"> RETAIL STORE</li>
                        <li>Mi Home</li>
                        <li>Mi Authorized Store</li>
                        <li>Mi Store Franchise</li>
                    </ul>
                </aside>
                <aside class="about">
                    <ul>
                        <li class="first">ABOUT US</li>
                        <li>Xiaomi</li>
                        <li>Privacy Policy</li>
                        <li>User Agrement</li>
                        <li>Integrity & Compliance</li>
                        <li>CSR and Disclosures</li>
                        <li>E-Waste Management</li>
                        <li>In the Press</li>
                        <li>Trust Center</li>
                        <li>Culture</li>
                        <li>Smart Phone Quality</li>
                        <li>Tv Quality</li>
                        <li>Service Quality</li>
                        <li>Xiaomi Hyper Os</li>
                        <li>Join Our Team</li>
                    </ul>
                </aside>
                <aside class="Follow">
                    <ul>
                        <li class="first">Follow Mi </li>
                        <li><i class="fa-brands fa-facebook"></i> <i class="fa-brands fa-x-twitter"></i> <i class="fa-brands fa-instagram"></i></li>
                        <li>Lets Stay in touch </li>
                        <li><input type="text" name="" id="" placeholder="    Enter email address "/></li>
                    </ul>
                </aside>
                </article>
            </section>
            <hr/>
            <section class="sub-footer">
                <div class="copy">
                    <span>Copyright © 2010 - 2025 Xiaomi. All Rights Reserved</span> 
                </div>
                <div class="site">
                    <aside>Site Maps</aside>
                    <aside>India / English <i class="fa-light fa-globe"></i></aside>
                </div>
            </section>
  </footer>

            </>)
}

export default Footer;
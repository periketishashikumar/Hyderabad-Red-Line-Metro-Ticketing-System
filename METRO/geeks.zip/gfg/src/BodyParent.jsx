import Bodychild from "./Bodychild"

let images = [
    {
        url:"https://media.geeksforgeeks.org/img-practice/prod/courses/517/Web/Content/Course_Software_testing_1720847295_1736594506.webp",
        desc:'DSA to development: A Comple.. ',
        mode:'Beginner to Advance',
        intrests:'476k+ Intrested Geeks'
    },
    {
        url:"https://media.geeksforgeeks.org/img-practice/prod/courses/227/Web/Content/backend_dev_1736591964.webp",
        desc:'Java Backend development ..',
        mode:'Intermediate to Advance',
        intrests:'274k+ Intrested Geeks'
    },
    {
        url:"https://media.geeksforgeeks.org/img-practice/prod/courses/458/Web/Content/Course_Tech_Int_1720846791_1736594646.webp",
        desc:'Tech Interview 101-From Ds..',
         mode:'Beginner to Advance',
        intrests:'319k+ Intrested Geeks'
    },
    {
        url:"https://media.geeksforgeeks.org/img-practice/prod/courses/517/Web/Content/Course_Software_testing_1720847295_1736594506.webp",
        desc:'Complete Software Testing ..',
         mode:'Beginner to Advance',
        intrests:'45k+ Intrested Geeks'
    },
     {
        url:"https://media.geeksforgeeks.org/img-practice/prod/courses/270/Web/Content/javaprogramming_1736593466.webp",
        desc:'Java Programming Online ...',
         mode:'Beginner to Advance',
        intrests:'264k+ Intrested Geeks'
    },
    {
        url:"https://media.geeksforgeeks.org/img-practice/prod/courses/221/Web/Content/cpp_1736593581.webp",
        desc:'C++ Programmming Course O..',
        mode:'Beginner to Advance',
        intrests:'218k+ Intrested Geeks'
    },
    {
        url:"https://media.geeksforgeeks.org/img-practice/prod/courses/458/Web/Content/Course_Tech_Int_1720846791_1736594646.webp",
        desc:'Tech Interview 101-From Ds..',
         mode:'Beginner to Advance',
        intrests:'319k+ Intrested Geeks'
    },
    {
        url:"https://media.geeksforgeeks.org/img-practice/prod/courses/517/Web/Content/Course_Software_testing_1720847295_1736594506.webp",
        desc:'Complete Software Testing ..',
         mode:'Beginner to Advance',
        intrests:'45k+ Intrested Geeks'
    },
     {
        url:"https://media.geeksforgeeks.org/img-practice/prod/courses/270/Web/Content/javaprogramming_1736593466.webp",
        desc:'Java Programming Online ...',
         mode:'Beginner to Advance',
        intrests:'264k+ Intrested Geeks'
    }
]

let Bodyparent = ()=>{
    return <>
        {
            images.map((images)=>{
                return <>
                <Bodychild images={images}/>
                </>

            })
        }
    
    </>
}
export default Bodyparent